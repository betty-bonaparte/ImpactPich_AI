import React from 'react';
import { BusinessData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { TrendingUp, Wallet, PieChart } from 'lucide-react';

interface DashboardProps {
  data: BusinessData;
}

export const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const chartData = [
    { name: 'Investimento', value: data.investmentAsk || 0, color: '#F97316' },
    { name: 'Retorno (Est.)', value: data.projectedReturn || 0, color: '#10B981' },
  ];

  const isEmpty = !data.investmentAsk && !data.projectedReturn;

  return (
    <div className="max-w-5xl mx-auto">
      <h2 className="text-3xl font-bold text-slate-900 mb-8">Dashboard de Impacto</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between h-40">
           <div>
               <p className="text-slate-500 text-sm font-medium mb-1">Investimento Solicitado</p>
               <h3 className="text-2xl font-bold text-slate-800">R$ {data.investmentAsk?.toLocaleString() || '0'}</h3>
           </div>
           <div className="bg-orange-50 w-10 h-10 rounded-full flex items-center justify-center text-orange-500">
               <Wallet size={20} />
           </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between h-40">
           <div>
               <p className="text-slate-500 text-sm font-medium mb-1">ROI Estimado</p>
               <h3 className="text-2xl font-bold text-emerald-600">
                {data.investmentAsk > 0 
                    ? `${(((data.projectedReturn - data.investmentAsk) / data.investmentAsk) * 100).toFixed(0)}%` 
                    : '0%'}
               </h3>
           </div>
           <div className="bg-emerald-50 w-10 h-10 rounded-full flex items-center justify-center text-emerald-500">
               <TrendingUp size={20} />
           </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex flex-col justify-between h-40">
           <div>
               <p className="text-slate-500 text-sm font-medium mb-1">Saúde do Projeto</p>
               <h3 className="text-2xl font-bold text-blue-900">{isEmpty ? 'Pendente' : 'Em Análise'}</h3>
           </div>
           <div className="bg-blue-50 w-10 h-10 rounded-full flex items-center justify-center text-blue-500">
               <PieChart size={20} />
           </div>
        </div>
      </div>

      <div className="bg-white p-8 rounded-xl border border-slate-100 shadow-sm">
        <h3 className="text-lg font-bold text-slate-800 mb-6">Projeção Financeira</h3>
        <div className="h-[300px] w-full">
            {isEmpty ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-100 rounded-lg">
                    <PieChart size={48} className="mb-4 opacity-50" />
                    <p>Preencha os dados no Wizard para visualizar</p>
                </div>
            ) : (
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748B'}} dy={10} />
                    <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748B'}} tickFormatter={(value) => `R$ ${value/1000}k`} />
                    <Tooltip 
                        cursor={{fill: '#F1F5F9'}}
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} 
                    />
                    <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={80}>
                        {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                    </Bar>
                    </BarChart>
                </ResponsiveContainer>
            )}
        </div>
      </div>
    </div>
  );
};
