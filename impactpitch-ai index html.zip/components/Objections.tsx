import React, { useState } from 'react';
import { MOCK_DATA } from '../constants';
// Fixed: Added Sparkles to imports
import { ChevronDown, ChevronUp, MessageCircle, ShieldCheck, Sparkles } from 'lucide-react';
import { BusinessData } from '../types';
import { GoogleGenAI } from "@google/genai";

interface ObjectionsProps {
  data: BusinessData;
}

export const Objections: React.FC<ObjectionsProps> = ({ data }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [aiAnswer, setAiAnswer] = useState<{index: number, text: string} | null>(null);
  const [loadingIndex, setLoadingIndex] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const generateAIResponse = async (index: number, question: string) => {
    if (!process.env.API_KEY) {
      alert("Configure a API Key para gerar respostas personalizadas.");
      return;
    }
    
    setLoadingIndex(index);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      // Contextualize with user data
      const context = `Contexto do Projeto: ${data.projectName}, Setor: ${data.sector}, Solução: ${data.solution}.`;
      const prompt = `${context} Como um empreendedor experiente, responda a esta pergunta de um investidor de forma concisa e confiante: "${question}"`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt
      });
      
      if (response.text) {
        setAiAnswer({ index, text: response.text });
      }
    } catch (e) {
      console.error(e);
      alert("Erro ao gerar resposta.");
    } finally {
      setLoadingIndex(null);
    }
  };

  return (
    <div className="max-w-3xl mx-auto animate-fadeIn">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Matriz de Objeções</h2>
        <p className="text-slate-500">Esteja preparado para as perguntas difíceis. Baseado no setor: <span className="font-semibold text-emerald-600">{data.sector || "Geral"}</span></p>
      </div>

      <div className="space-y-4">
        {MOCK_DATA.objections.map((obj, index) => {
          const isOpen = openIndex === index;
          return (
            <div 
              key={index} 
              className={`bg-white rounded-xl border transition-all duration-300 ${isOpen ? 'border-blue-200 shadow-md' : 'border-slate-100 shadow-sm hover:border-slate-300'}`}
            >
              <button
                onClick={() => toggleAccordion(index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left focus:outline-none"
              >
                <div className="flex items-center">
                   <div className={`p-2 rounded-full mr-4 ${isOpen ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>
                      <MessageCircle size={20} />
                   </div>
                   <span className={`font-semibold text-lg ${isOpen ? 'text-blue-900' : 'text-slate-700'}`}>
                     {obj.question}
                   </span>
                </div>
                {isOpen ? <ChevronUp className="text-slate-400" /> : <ChevronDown className="text-slate-400" />}
              </button>
              
              {isOpen && (
                <div className="px-6 pb-6 pl-[4.5rem]">
                  <div className="bg-slate-50 rounded-lg p-4 border border-slate-100 text-slate-700 leading-relaxed mb-4">
                    <div className="flex items-center mb-2 text-emerald-600 text-sm font-bold uppercase tracking-wider">
                        <ShieldCheck size={14} className="mr-1" /> Resposta Padrão
                    </div>
                    {obj.answer}
                  </div>

                  {/* AI Section */}
                  {aiAnswer?.index === index ? (
                     <div className="bg-blue-50 rounded-lg p-4 border border-blue-100 text-blue-900 leading-relaxed animate-fadeIn">
                        <div className="flex items-center mb-2 text-blue-600 text-sm font-bold uppercase tracking-wider">
                            <Sparkles size={14} className="mr-1" /> Sugestão AI Personalizada
                        </div>
                        {aiAnswer.text}
                     </div>
                  ) : (
                    <button 
                        onClick={() => generateAIResponse(index, obj.question)}
                        disabled={loadingIndex === index}
                        className="text-sm text-blue-600 hover:text-blue-800 font-medium flex items-center mt-2 disabled:opacity-50"
                    >
                        {loadingIndex === index ? (
                            <span>Gerando...</span>
                        ) : (
                            <>
                                <Sparkles size={14} className="mr-1" /> Personalizar resposta com IA (Gemini)
                            </>
                        )}
                    </button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};