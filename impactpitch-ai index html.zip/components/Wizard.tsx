import React, { useState, useEffect } from 'react';
import { BusinessData } from '../types';
import { MOCK_DATA } from '../constants';
import { GoogleGenAI } from "@google/genai";
import { ArrowRight, Sparkles, Check, ArrowLeft } from 'lucide-react';

interface WizardProps {
  data: BusinessData;
  onUpdate: (data: BusinessData) => void;
  onComplete: () => void;
}

const STEPS = [
  { id: 1, title: "O Básico", icon: "🌱" },
  { id: 2, title: "O Problema", icon: "🔥" },
  { id: 3, title: "Impacto & Finanças", icon: "💰" }
];

export const Wizard: React.FC<WizardProps> = ({ data, onUpdate, onComplete }) => {
  const [step, setStep] = useState(1);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleNext = () => {
    if (step < STEPS.length) setStep(step + 1);
    else onComplete();
  };

  const handlePrev = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleChange = (field: keyof BusinessData, value: any) => {
    onUpdate({ ...data, [field]: value });
  };

  const loadTemplate = () => {
    const template = MOCK_DATA.templates[data.sector];
    if (template) {
      onUpdate({
        ...data,
        problem: template.problem,
        solution: template.solution
      });
    }
  };

  // AI Enhancement Feature
  const enhanceText = async (field: 'problem' | 'solution') => {
    if (!process.env.API_KEY) {
      alert("Configure sua API_KEY para usar recursos de IA. Usando template de exemplo.");
      loadTemplate();
      return;
    }

    if (!data[field]) return;

    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Melhore este texto para um pitch deck de investidores, torne-o mais persuasivo e conciso (máximo 2 frases): "${data[field]}"`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
      });
      
      if (response.text) {
        handleChange(field, response.text.trim());
      }
    } catch (error) {
      console.error("AI Error", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
      {/* Progress Bar */}
      <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
        {STEPS.map((s) => (
          <div key={s.id} className={`flex items-center space-x-2 ${step === s.id ? 'text-blue-900 font-semibold' : 'text-slate-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${step === s.id ? 'bg-blue-100 text-blue-800' : 'bg-slate-100'}`}>
              {s.id}
            </div>
            <span className="hidden sm:inline">{s.title}</span>
          </div>
        ))}
      </div>

      <div className="p-8 min-h-[400px]">
        {step === 1 && (
          <div className="space-y-6 animate-fadeIn">
            <h2 className="text-2xl font-bold text-slate-800">Vamos começar pelo básico</h2>
            <p className="text-slate-500">Qual é a identidade do seu projeto de impacto?</p>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Nome do Projeto</label>
              <input
                type="text"
                className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
                placeholder="Ex: Amazonia Tech"
                value={data.projectName}
                onChange={(e) => handleChange('projectName', e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Setor</label>
              <select
                className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                value={data.sector}
                onChange={(e) => handleChange('sector', e.target.value)}
              >
                <option value="">Selecione um setor...</option>
                {MOCK_DATA.sectors.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-end">
                <h2 className="text-2xl font-bold text-slate-800">Problema & Solução</h2>
                {data.sector && MOCK_DATA.templates[data.sector] && (
                     <button onClick={loadTemplate} className="text-sm text-emerald-600 hover:text-emerald-700 font-medium flex items-center">
                        <Sparkles size={14} className="mr-1" /> Usar Exemplo
                     </button>
                )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Qual problema vocês resolvem?</label>
              <div className="relative">
                <textarea
                  className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none h-24 resize-none"
                  placeholder="Descreva a dor do mercado ou da comunidade..."
                  value={data.problem}
                  onChange={(e) => handleChange('problem', e.target.value)}
                />
                <button 
                  onClick={() => enhanceText('problem')}
                  disabled={isGenerating || !data.problem}
                  className="absolute bottom-3 right-3 text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-2 py-1 rounded-md transition-colors flex items-center"
                >
                  <Sparkles size={12} className="mr-1" /> {isGenerating ? 'Melhorando...' : 'Melhorar com IA'}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Qual a sua solução?</label>
              <div className="relative">
                <textarea
                  className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none h-24 resize-none"
                  placeholder="Sua inovação tecnológica ou social..."
                  value={data.solution}
                  onChange={(e) => handleChange('solution', e.target.value)}
                />
                 <button 
                  onClick={() => enhanceText('solution')}
                  disabled={isGenerating || !data.solution}
                  className="absolute bottom-3 right-3 text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-2 py-1 rounded-md transition-colors flex items-center"
                >
                  <Sparkles size={12} className="mr-1" /> {isGenerating ? 'Melhorando...' : 'Melhorar com IA'}
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6 animate-fadeIn">
             <h2 className="text-2xl font-bold text-slate-800">Números & Impacto</h2>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Métricas de Impacto (KPIs)</label>
              <input
                type="text"
                className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="Ex: 500 famílias atendidas, 2k toneladas de CO2..."
                value={data.impactMetrics}
                onChange={(e) => handleChange('impactMetrics', e.target.value)}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Investimento (R$)</label>
                <input
                    type="number"
                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    placeholder="100000"
                    value={data.investmentAsk || ''}
                    onChange={(e) => handleChange('investmentAsk', parseFloat(e.target.value))}
                />
                </div>
                <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Retorno Projetado (R$)</label>
                <input
                    type="number"
                    className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    placeholder="300000"
                    value={data.projectedReturn || ''}
                    onChange={(e) => handleChange('projectedReturn', parseFloat(e.target.value))}
                />
                </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Modelo Financeiro (Resumo)</label>
              <input
                type="text"
                className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="Ex: SaaS B2B, Venda Direta, Freemium..."
                value={data.financialModel}
                onChange={(e) => handleChange('financialModel', e.target.value)}
              />
            </div>
          </div>
        )}
      </div>

      <div className="bg-slate-50 px-8 py-5 border-t border-slate-100 flex justify-between">
        <button
          onClick={handlePrev}
          disabled={step === 1}
          className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-colors ${step === 1 ? 'text-slate-300 cursor-not-allowed' : 'text-slate-600 hover:bg-slate-200'}`}
        >
          <ArrowLeft size={16} className="mr-2" /> Voltar
        </button>
        <button
          onClick={handleNext}
          className="flex items-center bg-blue-900 hover:bg-blue-800 text-white px-6 py-2 rounded-lg text-sm font-medium shadow-md hover:shadow-lg transition-all transform active:scale-95"
        >
          {step === STEPS.length ? 'Finalizar & Gerar Deck' : 'Próximo'}
          {step !== STEPS.length && <ArrowRight size={16} className="ml-2" />}
          {step === STEPS.length && <Check size={16} className="ml-2" />}
        </button>
      </div>
    </div>
  );
};
