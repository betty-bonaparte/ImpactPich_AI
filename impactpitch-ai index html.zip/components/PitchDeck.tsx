import React from 'react';
import { BusinessData } from '../types';
// Fixed: Added Sparkles to imports
import { Printer, TrendingUp, Target, Users, DollarSign, Sparkles } from 'lucide-react';

interface PitchDeckProps {
  data: BusinessData;
}

// Fixed: Moved SlideCard component outside PitchDeck to avoid recreation on render and fix type inference issues with children
const SlideCard = ({ title, children, className = "" }: { title: string, children: React.ReactNode, className?: string }) => (
  <div className={`break-inside-avoid bg-white border border-slate-200 rounded-xl p-8 shadow-sm flex flex-col h-[400px] relative overflow-hidden print:shadow-none print:border-2 print:border-slate-800 print:h-[180mm] print:mb-8 ${className}`}>
    <div className="absolute top-0 left-0 w-2 h-full bg-emerald-500"></div>
    <h3 className="text-xs font-bold tracking-widest text-slate-400 uppercase mb-6">{title}</h3>
    <div className="flex-1 flex flex-col justify-center">
      {children}
    </div>
    <div className="absolute bottom-6 right-8 text-slate-300 print:text-slate-400">
      <span className="font-bold text-lg">ImpactPitch</span>
    </div>
  </div>
);

export const PitchDeck: React.FC<PitchDeckProps> = ({ data }) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex justify-between items-center mb-8 no-print">
        <div>
            <h2 className="text-3xl font-bold text-slate-900">Seu Pitch Deck</h2>
            <p className="text-slate-500">Pronto para apresentar. Clique em imprimir para salvar como PDF.</p>
        </div>
        <button
          onClick={handlePrint}
          className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-medium shadow-lg hover:shadow-orange-500/30 transition-all flex items-center transform active:scale-95"
        >
          <Printer size={20} className="mr-2" />
          Imprimir PDF
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 print:block print:gap-0">
        {/* Slide 1: Cover */}
        <SlideCard title="CAPA" className="bg-gradient-to-br from-white to-slate-50">
          <h1 className="text-5xl font-extrabold text-blue-900 mb-4 leading-tight">{data.projectName || "Nome do Projeto"}</h1>
          <p className="text-xl text-emerald-600 font-medium mb-8">{data.sector || "Setor de Atuação"}</p>
          <div className="inline-flex items-center text-slate-500">
            <Users className="mr-2" size={20} />
            <span>Empreendedorismo de Impacto</span>
          </div>
        </SlideCard>

        {/* Slide 2: Problem & Solution */}
        <SlideCard title="PROBLEMA & SOLUÇÃO">
          <div className="space-y-8">
            <div>
              <div className="flex items-center text-orange-500 mb-2 font-bold">
                 <Target className="mr-2" size={24} /> O Problema
              </div>
              <p className="text-xl text-slate-700 leading-relaxed font-light">
                "{data.problem || "O problema principal que estamos resolvendo..."}"
              </p>
            </div>
            <div className="w-full h-px bg-slate-100"></div>
            <div>
              <div className="flex items-center text-emerald-600 mb-2 font-bold">
                 <Sparkles className="mr-2" size={24} /> A Solução
              </div>
              <p className="text-xl text-slate-700 leading-relaxed font-medium">
                "{data.solution || "Nossa solução inovadora..."}"
              </p>
            </div>
          </div>
        </SlideCard>

        {/* Slide 3: Impact Metrics */}
        <SlideCard title="MÉTRICAS DE IMPACTO">
          <div className="text-center">
             <div className="inline-block p-4 bg-emerald-50 rounded-full mb-6">
                <TrendingUp size={48} className="text-emerald-500" />
             </div>
             <h2 className="text-4xl font-bold text-slate-800 mb-4">{data.impactMetrics || "Métricas Chave"}</h2>
             <p className="text-slate-500 max-w-sm mx-auto">Impacto direto gerado pela operação no curto e médio prazo.</p>
          </div>
        </SlideCard>

        {/* Slide 4: The Ask */}
        <SlideCard title="INVESTIMENTO & RETORNO">
          <div className="grid grid-cols-2 gap-6">
             <div className="bg-blue-50 p-6 rounded-lg text-center border border-blue-100 print:border-blue-900">
                <DollarSign className="mx-auto text-blue-600 mb-2" size={32} />
                <p className="text-sm text-blue-800 uppercase font-bold tracking-wide">Busca</p>
                <p className="text-3xl font-bold text-blue-900">R$ {data.investmentAsk?.toLocaleString() || "0"}</p>
             </div>
             <div className="bg-emerald-50 p-6 rounded-lg text-center border border-emerald-100 print:border-emerald-900">
                <TrendingUp className="mx-auto text-emerald-600 mb-2" size={32} />
                <p className="text-sm text-emerald-800 uppercase font-bold tracking-wide">Projeção</p>
                <p className="text-3xl font-bold text-emerald-900">R$ {data.projectedReturn?.toLocaleString() || "0"}</p>
             </div>
          </div>
          <div className="mt-8">
             <p className="font-bold text-slate-700 mb-2">Modelo:</p>
             <p className="text-lg text-slate-600">{data.financialModel || "Modelo de negócio..."}</p>
          </div>
        </SlideCard>
      </div>
    </div>
  );
};