import { BusinessData } from '../types';
import { EMPTY_BUSINESS_DATA } from '../constants';

const STORAGE_KEY = 'impact_pitch_data';

export const saveProgress = (data: BusinessData): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error("Failed to save progress", e);
  }
};

export const loadProgress = (): BusinessData => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load progress", e);
  }
  return EMPTY_BUSINESS_DATA;
};

export const clearProgress = (): void => {
  localStorage.removeItem(STORAGE_KEY);
};
