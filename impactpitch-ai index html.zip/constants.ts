import { Objection, SectorTemplate, BusinessData } from './types';

export const MOCK_DATA = {
  sectors: ["Bioeconomia", "Educação", "Economia Circular", "Energia Renovável", "Saúde Acessível"],
  objections: [
    {
      question: "Como você escala o impacto sem perder qualidade?",
      answer: "Focamos em tecnologia social replicável e parcerias locais, mantendo o núcleo da metodologia centralizado via plataforma digital."
    },
    {
      question: "Qual o retorno financeiro esperado?",
      answer: "Projetamos breakeven em 18 meses com margem de 15%, reinvestindo 5% diretamente na missão de impacto."
    },
    {
      question: "Por que agora é o momento?",
      answer: "A regulação do mercado de carbono e o aumento da conscientização ESG criaram uma janela de oportunidade única para nossa solução."
    }
  ] as Objection[],
  templates: {
    "Bioeconomia": {
      problem: "A cadeia do açaí perde 40% do valor por falta de processamento local.",
      solution: "Micro-usinas solares de processamento nas comunidades."
    },
    "Educação": {
      problem: "Jovens de baixa renda não possuem acesso a mentorias de carreira.",
      solution: "Plataforma AI que conecta executivos aposentados a jovens talentos."
    },
    "Economia Circular": {
      problem: "Resíduos têxteis acabam em aterros sanitários massivamente.",
      solution: "Marketplace B2B para sobras de tecidos industriais."
    }
  } as Record<string, SectorTemplate>
};

export const EMPTY_BUSINESS_DATA: BusinessData = {
  projectName: "",
  sector: "",
  problem: "",
  solution: "",
  impactMetrics: "",
  financialModel: "",
  investmentAsk: 0,
  projectedReturn: 0
};
