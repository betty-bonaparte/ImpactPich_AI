export interface BusinessData {
  projectName: string;
  sector: string;
  problem: string;
  solution: string;
  impactMetrics: string;
  financialModel: string;
  investmentAsk: number;
  projectedReturn: number; // Simplified for chart
}

export interface Objection {
  question: string;
  answer: string;
}

export interface SectorTemplate {
  problem: string;
  solution: string;
}

export type ViewState = 'onboarding' | 'dashboard' | 'deck' | 'objections';

export enum AppColors {
  OFF_WHITE = '#F8FAFC',
  IMPACT_GREEN = '#10B981',
  TRUST_BLUE = '#1E3A8A',
  ACTION_ORANGE = '#F97316',
}
