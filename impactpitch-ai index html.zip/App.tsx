import React, { useState, useEffect } from 'react';
import { Wizard } from './components/Wizard';
import { PitchDeck } from './components/PitchDeck';
import { Objections } from './components/Objections';
import { Dashboard } from './components/Dashboard';
import { BusinessData, ViewState } from './types';
import { loadProgress, saveProgress } from './services/storageService';
import { LayoutDashboard, Presentation, MessageSquare, PenTool, Menu, X } from 'lucide-react';

const App: React.FC = () => {
  const [data, setData] = useState<BusinessData>(loadProgress());
  const [view, setView] = useState<ViewState>('onboarding');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    saveProgress(data);
  }, [data]);

  const handleUpdate = (newData: BusinessData) => {
    setData(newData);
  };

  const navItems = [
    { id: 'onboarding', label: 'Wizard', icon: PenTool },
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'deck', label: 'Pitch Deck', icon: Presentation },
    { id: 'objections', label: 'Objeções', icon: MessageSquare },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      {/* Navbar */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200 no-print">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0 flex items-center">
                 <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-lg mr-2 flex items-center justify-center text-white font-bold">I</div>
                 <span className="font-bold text-xl tracking-tight text-slate-800">ImpactPitch <span className="text-emerald-500">AI</span></span>
              </div>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-1 items-center">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = view === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setView(item.id as ViewState)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center transition-all ${
                      isActive 
                        ? 'bg-blue-50 text-blue-700' 
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <Icon size={16} className={`mr-2 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                    {item.label}
                  </button>
                );
              })}
            </div>

            {/* Mobile Menu Button */}
            <div className="flex items-center md:hidden">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-slate-500 hover:text-slate-700 p-2"
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
           <div className="md:hidden bg-white border-t border-slate-100 px-4 pt-2 pb-4 shadow-lg absolute w-full">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                        setView(item.id as ViewState);
                        setMobileMenuOpen(false);
                    }}
                    className={`block w-full text-left px-3 py-3 rounded-md text-base font-medium mt-1 flex items-center ${
                      view === item.id ? 'bg-blue-50 text-blue-700' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                     <Icon size={18} className="mr-3" /> {item.label}
                  </button>
                );
              })}
           </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fadeIn">
        {view === 'onboarding' && (
          <Wizard 
            data={data} 
            onUpdate={handleUpdate} 
            onComplete={() => setView('deck')} 
          />
        )}
        {view === 'deck' && <PitchDeck data={data} />}
        {view === 'objections' && <Objections data={data} />}
        {view === 'dashboard' && <Dashboard data={data} />}
      </main>

      <footer className="bg-white border-t border-slate-200 py-6 mt-auto no-print">
        <div className="max-w-6xl mx-auto px-4 text-center text-slate-400 text-sm">
          <p>© 2024 ImpactPitch AI. Feito para empreendedores sociais.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
